from django import forms
from .models import Insumo, Receta, Ingrediente, MenuDiario

class InsumoForm(forms.ModelForm):
    class Meta:
        model = Insumo
        fields = '__all__'

class RecetaForm(forms.ModelForm):
    class Meta:
        model = Receta
        fields = '__all__'

class IngredienteForm(forms.ModelForm):
    class Meta:
        model = Ingrediente
        fields = '__all__'

class MenuDiarioForm(forms.ModelForm):
    class Meta:
        model = MenuDiario
        fields = ['fecha', 'receta', 'temporada', 'comensales']  # Sólo estos campos visibles
        widgets = {
            'fecha': forms.DateInput(attrs={'type': 'date'}),
        }