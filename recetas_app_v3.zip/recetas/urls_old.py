from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'insumos', views.InsumoViewSet)
router.register(r'recetas', views.RecetaViewSet)
router.register(r'ingredientes', views.IngredienteViewSet)
router.register(r'menu-diario', views.MenuDiarioViewSet)

app_name = 'recetas'

urlpatterns = [
    path('', views.index, name='index'),
    path('api/', include(router.urls)),

    # Rutas de funcionalidades web
    path('calcular-insumos/', views.calcular_insumos_web, name='calcular_insumos_web'),
    path('exportar-excel/', views.exportar_insumos_excel, name='exportar_insumos_excel'),
    path('historico-calculos/', views.historico_calculos, name='historico_calculos'),
    path('borrar-calculo/<int:calculo_id>/', views.borrar_calculo, name='borrar_calculo'),  # ESTA ES LA URL QUE FALTABA

    # Otras rutas
    path('listar/', views.receta_list, name='receta_list'),
    path('listar_urls/', views.listar_urls, name='listar_urls'),

    # Recetas individuales
    path('recetas/<int:pk>/', views.ver_receta_completa, name='ver_receta_completa'),
    path('recetas/<int:pk>/editar/', views.receta_edit, name='receta_edit'),
    path('recetas/<int:pk>/eliminar/', views.receta_delete, name='receta_delete'),
    path('recetas/<int:pk>/exportar-pdf/', views.exportar_receta_pdf, name='exportar_receta_pdf'),
    path('recetas/<int:pk>/favorito/', views.toggle_favorito, name='toggle_favorito'),

    # Comentarios
    path('recetas/<int:pk>/comentar/', views.agregar_comentario, name='agregar_comentario'),
    path('recetas/comentario/<int:comentario_id>/responder/', views.responder_comentario, name='responder_comentario'),
    path('recetas/comentario/<int:comentario_id>/eliminar/', views.eliminar_comentario, name='eliminar_comentario'),

    # Favoritos y Notificaciones
    path('recetas/favoritos/', views.favoritos_list, name='favoritos_list'),
    path('recetas/notificaciones/', views.notificaciones_list, name='notificaciones_list'),
]
