from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.utils import timezone
from rest_framework import viewsets, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.permissions import IsAuthenticated
from .permissions import IsOwnerOrReadOnly
from .models import Insumo, Receta, Ingrediente, MenuDiario, CalculoInsumos, Favorito, Notificacion
from .serializers import InsumoSerializer, RecetaSerializer, IngredienteSerializer, MenuDiarioSerializer
from .forms import InsumoForm, RecetaForm, IngredienteForm, MenuDiarioForm
from django.urls import get_resolver
import requests
from datetime import datetime
from openpyxl import Workbook
import json
from io import BytesIO
from rest_framework_simplejwt.tokens import AccessToken
from django.shortcuts import render
from datetime import datetime
from collections import defaultdict
import openpyxl
from django.shortcuts import get_object_or_404, redirect
from .models import CalculoInsumos
from django.db.models import Q  # Asegurate de importar esto arriba 👆
from django.contrib import messages
from django.shortcuts import render, redirect
from .models import Insumo
import shutil
import os
from django.conf import settings
from django.http import FileResponse




# --- API ViewSets ---

class RecetaViewSet(viewsets.ModelViewSet):
    queryset = Receta.objects.all()
    serializer_class = RecetaSerializer
    permission_classes = [IsAuthenticated, IsOwnerOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['temporada', 'tipo_comida']
    search_fields = ['nombre']

    def perform_create(self, serializer):
        serializer.save(usuario=self.request.user)

class InsumoViewSet(viewsets.ModelViewSet):
    queryset = Insumo.objects.all()
    serializer_class = InsumoSerializer
    permission_classes = [IsAuthenticated, IsOwnerOrReadOnly]

    def perform_create(self, serializer):
        serializer.save(usuario=self.request.user)

class IngredienteViewSet(viewsets.ModelViewSet):
    queryset = Ingrediente.objects.all()
    serializer_class = IngredienteSerializer
    permission_classes = [IsAuthenticated, IsOwnerOrReadOnly]

    def perform_create(self, serializer):
        serializer.save(usuario=self.request.user)

class MenuDiarioViewSet(viewsets.ModelViewSet):
    queryset = MenuDiario.objects.all()
    serializer_class = MenuDiarioSerializer
    permission_classes = [IsAuthenticated, IsOwnerOrReadOnly]

    def perform_create(self, serializer):
        serializer.save(usuario=self.request.user)

    @action(detail=False, methods=['get'])
    def calcular_insumos(self, request):
        fecha_inicio = request.query_params.get('fecha_inicio')
        fecha_fin = request.query_params.get('fecha_fin')
        temporada = request.query_params.get('temporada', 'verano')

        try:
            fecha_inicio = datetime.strptime(fecha_inicio, '%Y-%m-%d').date()
            fecha_fin = datetime.strptime(fecha_fin, '%Y-%m-%d').date()
        except (ValueError, TypeError):
            return Response({"error": "Formato de fecha inválido. Use YYYY-MM-DD."}, status=400)

        menus = MenuDiario.objects.filter(fecha__range=[fecha_inicio, fecha_fin], temporada=temporada)
        insumos_necesarios = {}

        for menu in menus:
            receta = menu.receta
            factor = menu.comensales / receta.porciones
            ingredientes = Ingrediente.objects.filter(receta=receta)
            for ingrediente in ingredientes:
                insumo = ingrediente.insumo
                cantidad = ingrediente.cantidad * factor
                if insumo.nombre in insumos_necesarios:
                    insumos_necesarios[insumo.nombre] += cantidad
                else:
                    insumos_necesarios[insumo.nombre] = cantidad

        resultado = [
            {
                'codigo': Insumo.objects.get(nombre=nombre).codigo,
                'insumo': nombre,
                'cantidad': round(cantidad, 2),
                'unidad': Insumo.objects.get(nombre=nombre).unidad
            }
            for nombre, cantidad in insumos_necesarios.items()
        ]

        CalculoInsumos.objects.create(
            fecha_inicio=fecha_inicio,
            fecha_fin=fecha_fin,
            temporada=temporada,
            insumos=json.dumps(resultado),
            usuario=request.user
        )

        return Response(resultado)

# --- Vistas Web ---

def index(request):
    recetas = Receta.objects.all().order_by('-id')[:5]
    menus = MenuDiario.objects.all().order_by('-fecha')[:5]
    notificaciones_no_leidas = Notificacion.objects.filter(usuario=request.user, leida=False).count()
    return render(request, 'recetas/index.html', {
        'recetas': recetas,
        'menus': menus,
        'notificaciones_no_leidas': notificaciones_no_leidas,
    })

@login_required
def agregar_insumo(request):
    if request.method == 'POST':
        form = InsumoForm(request.POST)
        if form.is_valid():
            insumo = form.save(commit=False)
            insumo.usuario = request.user
            insumo.save()
            return redirect('recetas:agregar_insumo')
    else:
        form = InsumoForm()
    return render(request, 'recetas/agregar_insumo.html', {'form': form})

@login_required
def agregar_receta(request):
    if request.method == 'POST':
        form = RecetaForm(request.POST, request.FILES)
        if form.is_valid():
            receta = form.save(commit=False)
            receta.usuario = request.user
            receta.save()
            return redirect('recetas:receta_list')
    else:
        form = RecetaForm()
    return render(request, 'recetas/agregar_receta.html', {'form': form})

@login_required
def agregar_ingrediente(request):
    if request.method == 'POST':
        form = IngredienteForm(request.POST)
        if form.is_valid():
            ingrediente = form.save(commit=False)
            ingrediente.usuario = request.user
            ingrediente.save()
            return redirect('recetas:agregar_ingrediente')
    else:
        form = IngredienteForm()
    return render(request, 'recetas/agregar_ingrediente.html', {'form': form})

@login_required
def agregar_menu_diario(request):
    if request.method == 'POST':
        form = MenuDiarioForm(request.POST)
        if form.is_valid():
            menu = form.save(commit=False)
            menu.usuario = request.user  # 🎯 Guarda el usuario que está logueado
            menu.save()
            return redirect('recetas:agregar_menu_diario')
    else:
        form = MenuDiarioForm()
    return render(request, 'recetas/agregar_menu_diario.html', {'form': form})

@login_required
@login_required
def calcular_insumos_web(request):
    fecha_inicio = request.GET.get('fecha_inicio')
    fecha_fin = request.GET.get('fecha_fin')
    temporada = request.GET.get('temporada')

    insumos = []
    menus = []

    if fecha_inicio and fecha_fin and temporada:
        try:
            fecha_inicio_obj = datetime.strptime(fecha_inicio, '%Y-%m-%d').date()
            fecha_fin_obj = datetime.strptime(fecha_fin, '%Y-%m-%d').date()

            filtros = {
                'fecha__range': (fecha_inicio_obj, fecha_fin_obj),
                'temporada': temporada,
                # 'usuario': request.user   # Cuando quieras multiusuario real
            }

            menus = MenuDiario.objects.filter(**filtros).select_related('receta').prefetch_related('receta__ingredientes__insumo')

            print(f"Menús encontrados: {menus.count()}")
            for menu in menus:
                print(f"Menu: {menu.fecha} - {menu.receta.nombre} - {menu.temporada}")

            insumo_totales = defaultdict(lambda: {'nombre': '', 'unidad': '', 'cantidad': 0})

            for menu in menus:
                receta = menu.receta
                comensales = menu.comensales

                for ingrediente in receta.ingredientes.all():
                    insumo = ingrediente.insumo
                    cantidad_total = ingrediente.cantidad * comensales / receta.porciones
                    codigo = insumo.codigo

                    insumo_totales[codigo]['nombre'] = insumo.nombre
                    insumo_totales[codigo]['unidad'] = insumo.unidad
                    insumo_totales[codigo]['cantidad'] += cantidad_total

            insumos = [
                {'codigo': codigo, 'insumo': datos['nombre'], 'unidad': datos['unidad'], 'cantidad': round(datos['cantidad'], 2)}
                for codigo, datos in insumo_totales.items()
            ]

            insumos = sorted(insumos, key=lambda x: x['insumo'].lower())

            # GUARDA EL HISTORICO SIEMPRE
            if insumos:
                print("Guardando cálculo con insumos...")
            else:
                print("No hay insumos, igual guardamos histórico vacío para testear...")

            CalculoInsumos.objects.create(
                fecha_inicio=fecha_inicio_obj,
                fecha_fin=fecha_fin_obj,
                temporada=temporada,
                insumos=json.dumps(insumos),
                usuario=request.user
            )

        except Exception as e:
            print(f"Error en el cálculo de insumos: {e}")

    contexto = {
        'fecha_inicio': fecha_inicio,
        'fecha_fin': fecha_fin,
        'temporada': temporada,
        'insumos': insumos,
        'menus': menus,
    }

    return render(request, 'recetas/calcular_insumos.html', contexto)

@login_required
def exportar_insumos_excel(request):
    fecha_inicio = request.GET.get('fecha_inicio')
    fecha_fin = request.GET.get('fecha_fin')
    temporada = request.GET.get('temporada')

    if not (fecha_inicio and fecha_fin and temporada):
        return HttpResponse("Faltan parámetros para exportar.", status=400)

    insumo_totales = defaultdict(lambda: {'nombre': '', 'unidad': '', 'cantidad': 0})

    try:
        fecha_inicio_obj = datetime.strptime(fecha_inicio, '%Y-%m-%d').date()
        fecha_fin_obj = datetime.strptime(fecha_fin, '%Y-%m-%d').date()

        # Armamos el filtro base
        filtros = {
            'fecha__range': (fecha_inicio_obj, fecha_fin_obj),
            'temporada': temporada,
            # Si querés en producción podés agregar 'usuario': request.user
        }

        menus = MenuDiario.objects.filter(**filtros).select_related('receta').prefetch_related('receta__ingredientes__insumo')

        for menu in menus:
            receta = menu.receta
            comensales = menu.comensales

            for ingrediente in receta.ingredientes.all():
                insumo = ingrediente.insumo
                cantidad_total = ingrediente.cantidad * comensales / receta.porciones
                codigo = insumo.codigo

                insumo_totales[codigo]['nombre'] = insumo.nombre
                insumo_totales[codigo]['unidad'] = insumo.unidad
                insumo_totales[codigo]['cantidad'] += cantidad_total

    except Exception as e:
        return HttpResponse(f"Error al calcular insumos: {e}", status=500)

    # Crear el Excel
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Insumos Necesarios"

    # Encabezados
    ws.append(['Código', 'Insumo', 'Cantidad', 'Unidad'])

    # Datos
    for codigo, datos in insumo_totales.items():
        ws.append([codigo, datos['nombre'], round(datos['cantidad'], 2), datos['unidad']])

    # Armar la respuesta
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    filename = f"insumos_{fecha_inicio}_a_{fecha_fin}.xlsx"
    response['Content-Disposition'] = f'attachment; filename={filename}'
    wb.save(response)
    return response



@login_required
def historico_calculos(request):
    calculos = CalculoInsumos.objects.all().order_by('-fecha_calculo')  # 👈 sin filtro de usuario
    for calculo in calculos:
        try:
            calculo.insumos = json.loads(calculo.insumos)
        except Exception:
            calculo.insumos = []

    return render(request, 'recetas/historico_calculos.html', {'calculos': calculos})



@login_required
def receta_list(request):
    query = request.GET.get('q', '')
    temporada = request.GET.get('temporada', '')
    tipo_comida = request.GET.get('tipo_comida', '')
    recetas = Receta.objects.all()
    if query:
        recetas = recetas.filter(nombre__icontains=query)
    if temporada:
        recetas = recetas.filter(temporada=temporada)
    if tipo_comida:
        recetas = recetas.filter(tipo_comida=tipo_comida)
    return render(request, 'recetas/receta_list.html', {
        'recetas': recetas,
        'query': query,
        'temporada': temporada,
        'tipo_comida': tipo_comida,
    })

@login_required
def receta_edit(request, pk):
    receta = get_object_or_404(Receta, pk=pk)
    if request.method == 'POST':
        form = RecetaForm(request.POST, request.FILES, instance=receta)
        if form.is_valid():
            form.save()
            return redirect('recetas:receta_list')
    else:
        form = RecetaForm(instance=receta)
    return render(request, 'recetas/receta_form.html', {'form': form})

@login_required
def receta_delete(request, pk):
    receta = get_object_or_404(Receta, pk=pk)
    if request.method == 'POST':
        receta.delete()
        return redirect('recetas:receta_list')
    return render(request, 'recetas/receta_confirm_delete.html', {'receta': receta})

@login_required
def ver_receta_completa(request, pk):
    receta = get_object_or_404(Receta, pk=pk)
    ingredientes = Ingrediente.objects.filter(receta=receta)
    return render(request, 'recetas/ver_receta_completa.html', {
        'receta': receta,
        'ingredientes': ingredientes,
    })

@login_required
def toggle_favorito(request, pk):
    receta = get_object_or_404(Receta, pk=pk)
    favorito, created = Favorito.objects.get_or_create(usuario=request.user, receta=receta)
    if created:
        Notificacion.objects.create(
            usuario=request.user,
            mensaje=f"Has añadido '{receta.nombre}' a tus favoritos."
        )
    else:
        favorito.delete()
        Notificacion.objects.create(
            usuario=request.user,
            mensaje=f"Has eliminado '{receta.nombre}' de tus favoritos."
        )
    return redirect('recetas:ver_receta_completa', pk=pk)

@login_required
def favoritos_list(request):
    favoritos = Favorito.objects.filter(usuario=request.user)
    return render(request, 'recetas/favoritos_list.html', {'favoritos': favoritos})

@login_required
def agregar_comentario(request, pk):
    receta = get_object_or_404(Receta, pk=pk)
    if request.method == 'POST':
        form = ComentarioForm(request.POST)
        if form.is_valid():
            comentario = form.save(commit=False)
            comentario.usuario = request.user
            comentario.receta = receta
            comentario.save()
            return redirect('recetas:ver_receta_completa', pk=pk)
    else:
        form = ComentarioForm()
    return render(request, 'recetas/agregar_comentario.html', {'form': form, 'receta': receta})

@login_required
def responder_comentario(request, comentario_id):
    comentario = get_object_or_404(Comentario, id=comentario_id)
    if request.method == 'POST':
        form = ComentarioForm(request.POST)
        if form.is_valid():
            respuesta = form.save(commit=False)
            respuesta.usuario = request.user
            respuesta.receta = comentario.receta
            respuesta.padre = comentario
            respuesta.save()
            return redirect('recetas:ver_receta_completa', pk=comentario.receta.id)
    else:
        form = ComentarioForm()
    return render(request, 'recetas/responder_comentario.html', {'form': form, 'comentario': comentario})

@login_required
def eliminar_comentario(request, comentario_id):
    comentario = get_object_or_404(Comentario, id=comentario_id, usuario=request.user)
    receta_id = comentario.receta.id
    if request.method == 'POST':
        comentario.delete()
        return redirect('recetas:ver_receta_completa', pk=receta_id)
    return render(request, 'recetas/eliminar_comentario.html', {'comentario': comentario})

@login_required
def notificaciones_list(request):
    notificaciones = Notificacion.objects.filter(usuario=request.user).order_by('-fecha')
    if request.method == 'POST':
        notificaciones.update(leida=True)  # Marcar todas como leídas
    return render(request, 'recetas/notificaciones_list.html', {'notificaciones': notificaciones})

@login_required
def exportar_receta_pdf(request, pk):
    receta = get_object_or_404(Receta, pk=pk)
    ingredientes = Ingrediente.objects.filter(receta=receta)

    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)

    # Encabezado
    p.setFont("Helvetica-Bold", 10)
    p.drawString(50, 780, "Gestión de Recetas")
    p.line(50, 775, 550, 775)

    # Título
    p.setFont("Helvetica-Bold", 16)
    p.drawString(100, 740, f"Receta: {receta.nombre}")

    # Detalles
    p.setFont("Helvetica", 12)
    p.drawString(100, 710, f"Código: {receta.codigo}")
    p.drawString(100, 690, f"Temporada: {receta.temporada}")
    p.drawString(100, 670, f"Tipo de Comida: {receta.tipo_comida}")
    p.drawString(100, 650, f"Porciones: {receta.porciones}")

    # Ingredientes
    p.setFont("Helvetica-Bold", 12)
    p.drawString(100, 620, "Ingredientes:")
    p.setFont("Helvetica", 12)
    y = 600
    for ingrediente in ingredientes:
        p.drawString(120, y, f"- {ingrediente.insumo.nombre}: {ingrediente.cantidad} {ingrediente.insumo.unidad}")
        y -= 20

    # Pie de página
    p.setFont("Helvetica", 8)
    p.drawString(50, 30, f"Generado el {timezone.now().strftime('%Y-%m-%d %H:%M:%S')}")
    p.drawString(450, 30, "Página 1")

    p.showPage()
    p.save()

    buffer.seek(0)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="receta_{receta.codigo}.pdf"'
    return response

def listar_urls(request):
    urls = []

    def extract_urls(url_patterns, prefix=''):
        for pattern in url_patterns:
            if hasattr(pattern, 'url_patterns'):
                extract_urls(pattern.url_patterns, prefix + str(pattern.pattern))
            else:
                full_url = prefix + str(pattern.pattern)
                urls.append({
                    'url': full_url,
                    'name': pattern.name if pattern.name else 'Sin nombre',
                    'view': str(pattern.callback) if pattern.callback else 'Sin vista'
                })

    extract_urls(get_resolver().url_patterns)
    return render(request, 'recetas/listar_urls.html', {'urls': urls})



from django.shortcuts import get_object_or_404, redirect
from django.shortcuts import render, get_object_or_404, redirect  # <-- agregá redirect acá si no lo tenías

@login_required
def borrar_calculo(request, calculo_id):
    calculo = get_object_or_404(CalculoInsumos, id=calculo_id)
    calculo.delete()
    return redirect('recetas:historico_calculos')

@login_required
def test_borrar_calculo(request):
    return HttpResponse("Funciona borrar_calculo")

@login_required
def gestionar_recetas(request):
    query = request.GET.get('q', '')
    recetas = Receta.objects.all()

    if query:
        recetas = recetas.filter(
            Q(nombre__icontains=query) |
            Q(codigo__icontains=query)
        )

    return render(request, 'recetas/gestionar_recetas.html', {'recetas': recetas, 'query': query})

@login_required
def importar_insumos(request):
    if request.method == 'POST' and request.FILES.get('archivo'):
        archivo = request.FILES['archivo']
        try:
            wb = openpyxl.load_workbook(archivo)
            hoja = wb.active

            # Empezamos desde la segunda fila (asumiendo que la primera tiene encabezados)
            for fila in hoja.iter_rows(min_row=2, values_only=True):
                codigo, nombre, unidad, presentacion = fila
                if codigo and nombre and unidad:
                    Insumo.objects.update_or_create(
                        codigo=codigo,
                        defaults={
                            'nombre': nombre,
                            'unidad': unidad,
                            'presentacion': presentacion if presentacion else 1,
                            'usuario': request.user
                        }
                    )

            messages.success(request, '¡Insumos importados exitosamente!')
            return redirect('recetas:importar_insumos')

        except Exception as e:
            messages.error(request, f"Error al procesar el archivo: {e}")
            return redirect('recetas:importar_insumos')

    return render(request, 'recetas/importar_insumos.html')

@login_required
def importar_recetas(request):
    if request.method == 'POST' and request.FILES.get('archivo'):
        archivo = request.FILES['archivo']
        try:
            wb = openpyxl.load_workbook(archivo)
            hoja = wb.active

            # Recorremos desde la segunda fila
            for fila in hoja.iter_rows(min_row=2, values_only=True):
                codigo, nombre, temporada, tipo_comida = fila
                if codigo and nombre and temporada and tipo_comida:
                    Receta.objects.get_or_create(
                        codigo=codigo,
                        defaults={
                            'nombre': nombre,
                            'temporada': temporada.lower(),  # asegurar minúscula
                            'tipo_comida': tipo_comida.lower(),  # asegurar minúscula
                            'usuario': request.user,
                            #'porciones': 1  # si no lo cargás en Excel, ponés 1
                        }
                    )

            messages.success(request, '¡Recetas importadas exitosamente!')
            return redirect('recetas:importar_recetas')

        except Exception as e:
            messages.error(request, f"Error al procesar el archivo: {e}")
            return redirect('recetas:importar_recetas')

    return render(request, 'recetas/importar_recetas.html')

@login_required
def importar_ingredientes(request):
    if request.method == 'POST' and request.FILES.get('archivo'):
        archivo = request.FILES['archivo']
        try:
            wb = openpyxl.load_workbook(archivo)
            hoja = wb.active

            for fila in hoja.iter_rows(min_row=2, values_only=True):
                codigo_insumo, codigo_receta, cantidad = fila
                if codigo_insumo and codigo_receta and cantidad:
                    insumo = Insumo.objects.get(codigo=str(codigo_insumo).strip())
                    receta = Receta.objects.get(codigo=str(codigo_receta).strip())

                    Ingrediente.objects.create(
                        insumo=insumo,
                        receta=receta,
                        cantidad=cantidad,
                        usuario=request.user
                    )

            messages.success(request, '¡Ingredientes importados exitosamente!')
            return redirect('recetas:importar_ingredientes')

        except Exception as e:
            messages.error(request, f"Error al procesar el archivo: {e}")
            return redirect('recetas:importar_ingredientes')

    return render(request, 'recetas/importar_ingredientes.html')


#Backup de la base de datos.
@login_required
def backup_bd(request):
    ruta_original = settings.BASE_DIR / 'db.sqlite3'
    ruta_backup = settings.BASE_DIR / 'backup_db.sqlite3'

    # Copiamos el archivo
    shutil.copy(ruta_original, ruta_backup)

    # Devolvemos el archivo como descarga
    response = FileResponse(open(ruta_backup, 'rb'), as_attachment=True, filename='backup_db.sqlite3')

    return response