# recetas/web_urls.py
from django.urls import path
from . import views

app_name = 'recetas'

urlpatterns = [
    # Página principal
    path('', views.index, name='index'),

    # Insumos
    path('agregar-insumo/', views.agregar_insumo, name='agregar_insumo'),
    path('importar-insumos/', views.importar_insumos, name='importar_insumos'),

    # Recetas
    path('agregar-receta/', views.agregar_receta, name='agregar_receta'),
    path('gestionar-recetas/', views.gestionar_recetas, name='gestionar_recetas'),
    path('importar-recetas/', views.importar_recetas, name='importar_recetas'),

    # Ingredientes
    path('agregar-ingrediente/', views.agregar_ingrediente, name='agregar_ingrediente'),
    path('importar-ingredientes/', views.importar_ingredientes, name='importar_ingredientes'),

    # Menú Diario
    path('agregar-menu-diario/', views.agregar_menu_diario, name='agregar_menu_diario'),

    # Cálculo de insumos
    path('calcular-insumos/', views.calcular_insumos_web, name='calcular_insumos_web'),
    path('exportar-excel/', views.exportar_insumos_excel, name='exportar_insumos_excel'),
    path('historico-calculos/', views.historico_calculos, name='historico_calculos'),
    path('borrar-calculo/<int:calculo_id>/', views.borrar_calculo, name='borrar_calculo'),

    # Gestión de recetas individuales
    path('recetas/<int:pk>/', views.ver_receta_completa, name='ver_receta_completa'),
    path('recetas/<int:pk>/editar/', views.receta_edit, name='receta_edit'),
    path('recetas/<int:pk>/eliminar/', views.receta_delete, name='receta_delete'),
    path('recetas/<int:pk>/exportar-pdf/', views.exportar_receta_pdf, name='exportar_receta_pdf'),
    path('recetas/<int:pk>/favorito/', views.toggle_favorito, name='toggle_favorito'),

    # Comentarios
    path('recetas/<int:pk>/comentar/', views.agregar_comentario, name='agregar_comentario'),
    path('recetas/comentario/<int:comentario_id>/responder/', views.responder_comentario, name='responder_comentario'),
    path('recetas/comentario/<int:comentario_id>/eliminar/', views.eliminar_comentario, name='eliminar_comentario'),

    # Favoritos y Notificaciones
    path('recetas/favoritos/', views.favoritos_list, name='favoritos_list'),
    path('recetas/notificaciones/', views.notificaciones_list, name='notificaciones_list'),

    # Utilidades
    path('listar-urls/', views.listar_urls, name='listar_urls'),
    path('backup/', views.backup_bd, name='backup_bd'),  # 👈 NUEVA RUTA
]
